import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewministatement',
  templateUrl: './viewministatement.component.html',
  styleUrls: ['./viewministatement.component.css']
})
export class ViewministatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
